<?php $__env->startSection('header'); ?>
    <header class="main-header">
        <!-- Logo -->
    <?php echo $__env->make('dashboard.brand', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top">
            <!-- Sidebar toggle button-->
            <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
                <span class="sr-only">Toggle navigation</span>
            </a>
            <!-- Navbar Right Menu -->
            <?php echo $__env->make('dashboard.userProfileLink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </nav>
    </header>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('allow-admin', [])->dom;
} elseif ($_instance->childHasBeenRendered('DfkjRFm')) {
    $componentId = $_instance->getRenderedChildComponentId('DfkjRFm');
    $componentTag = $_instance->getRenderedChildComponentTagName('DfkjRFm');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('DfkjRFm');
} else {
    $response = \Livewire\Livewire::mount('allow-admin', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('DfkjRFm', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>

<?php $__env->startSection('main-content'); ?>
    <div class="content-wrapper">
        <section class="content" xmlns:wire="http://www.w3.org/1999/xhtml" xmlns:nwire="http://www.w3.org/1999/xhtml">
            <div class="row col-md-10 col-lg-10 flex justify-content-center">

                    <div class="pull-right" style="width: 100%; display: flex; justify-content: center; align-items: center;">
                        <img src="<?php echo e(asset('custom/img')); ?>/nepza_logo.jpg" width="100" height="90" alt="" />
                        <span style="font-size: 24px; font-weight: bolder; color: #0c5460; line-height: 17px;">
                            NEPZA STAFF MULTIPURPOSE CO-OPERATIVE SOCIETY LIMITED<br />
                            <small style="font-size: 13px; color: #0c5460; align-items: center; ! important;">
                                2, Zambezi Crescent Cadestral Zone A6, Behind Merit House, Off Aguiyi Ironsi Street, Maitama, Abuja<br />
                               &#160;&#160;&#160; &#160; &#160; &#160; &#160; &#160; &#160;&#160; &#160; &#160; &#160; &#160; &#160; Contact GSM: 08054222750; 08086664932; Email: nepzacoop@yahoo.com<br />
                                &#160;&#160;&#160; &#160; &#160; &#160; &#160; &#160; &#160;&#160;&#160;&#160; &#160; &#160; &#160; &#160; &#160; &#160;&#160;&#160;&#160; &#160; &#160; &#160; &#160; &#160; &#160;
                                &#160;&#160;&#160; &#160; &#160; &#160; &#160; &#160; &#160;Motto: Unity & Progress
                            </small>
                        </span>
                    </div>
                </div>
             <!-- Content Wrapper. Contains page content -->
              <!-- Content Header (Page header) -->

            <!-- Main content -->
            <section class="content">
                <div class="row">
                    <div class="col-xs-12">

                        <div class="box box-danger" style="padding: 10px;">
                            <div class="box-header">
                                <div class="box-tools pull-right">
                                    <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                                    </button>
                                </div>
                                <h3 class="box-title">List View of all Loan</h3>
                            </div>
                            <!-- /.box-header -->
                            <div class="table-responsive">
                                    <table id="example1" class="table table-bordered table-striped">
                                        <thead>
                                        <tr>
                                            <th>Loan Type</th>
                                            <th>Loan Amount(<del style="text-decoration-style: double">N</del>)</th>
                                            <th>Total Payable(<del style="text-decoration-style: double">N</del>)</th>
                                            <th>Monthly Interest Payable(<del style="text-decoration-style: double">N</del>)</th>
                                            <th>Total Interest Payable(<del style="text-decoration-style: double">N</del>)</th>
                                            <th>Loan Balance</th>
                                            <th>Loan State</th>
                                            <th>Action</th>
                                        </tr>
                                        </thead>
                                            <?php $__currentLoopData = $loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($loan->loan_type); ?></td>
                                                    <td><?php echo e(number_format($loan->loan_amount,2)); ?></td>
                                                    <td><?php echo e(number_format($loan->total_amount_payable,2)); ?></td>
                                                    <td><?php echo e(number_format($loan->monthly_interest_payable,2)); ?></td>
                                                    <td><?php echo e(number_format($loan->total_interest_payable,2)); ?></td>
                                                    <td></td>
                                                    <?php if($loan->status=='Processing'): ?>
                                                    <td><span class="label label-warning"><?php echo e($loan->status); ?></span></td>
                                                    <?php endif; ?>
                                                    <?php if($loan->status=='Approved'): ?>
                                                        <td><span class="label label-success"><?php echo e($loan->status); ?></span></td>
                                                    <?php endif; ?>
                                                    <?php if($loan->status=='Settled'): ?>
                                                        <td><span class="label label-success"><?php echo e($loan->status); ?></span></td>
                                                    <?php endif; ?>
                                                    <?php if($loan->status=='Rejected'): ?>
                                                        <td><span class="label label-danger"><?php echo e($loan->status); ?></span></td>
                                                    <?php endif; ?>
                                                    <td>
                                                        <div class="input-group-btn">
                                                            <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                                                                <span class="fa fa-caret-down"></span></button>
                                                            <ul class="dropdown-menu">
                                                                <li><a href="/application/loanDetails/<?php echo e($loan->id); ?>/">View Detail</a></li>
                                                                <?php if($loan->status == 'Processing'): ?>
                                                                 <li><a href="/application/<?php echo e($loan->id); ?>/updateLoan/">Edit Loan</a></li>
                                                                <?php endif; ?>
                                                                <?php if($loan->status == 'Processing'): ?>
                                                                    <li>
                                                                        <a  style="cursor: pointer;" onclick="deleteLoan('<?php echo e($loan->id); ?>')" >Delete Application </a>
                                                                    </li>
                                                                <?php endif; ?>
                                                            </ul>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>
                                    <script>
                                        function deleteLoan(id) {
                                            var sure = confirm('Are you sure? This action cannot be reversed');
                                            if(sure ==false){
                                                return false;
                                            }else {
                                                data = {
                                                    loan_id: id, _token: "<?php echo e(csrf_token()); ?>"
                                                }
                                                $.ajax({
                                                    dataType: 'json',
                                                    type: "DELETE",
                                                    url: '<?php echo e(URL::to('/deleteApplication')); ?>',
                                                    data: data,
                                                    success: function (response) {
                                                        //location.reload();
                                                        window.location=response.url;
                                                    }
                                                });
                                            }
                                        }

                                    </script>
                                </div>
                            <!-- /.box-body -->
                        </div>
                        <!-- /.box -->
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </section>
            <!-- /.content -->

            <!-- /.content-wrapper -->
                <script>
                    $(function () {
                        $('#example1').DataTable()
                        $('#example2').DataTable({
                            'paging'      : true,
                            'lengthChange': false,
                            'searching'   : false,
                            'ordering'    : true,
                            'info'        : true,
                            'autoWidth'   : false
                        })
                    })
                </script>
    </section>

        <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('change-password', [])->dom;
} elseif ($_instance->childHasBeenRendered('39GtHoK')) {
    $componentId = $_instance->getRenderedChildComponentId('39GtHoK');
    $componentTag = $_instance->getRenderedChildComponentTagName('39GtHoK');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('39GtHoK');
} else {
    $response = \Livewire\Livewire::mount('change-password', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('39GtHoK', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
    </div>
    <footer class="main-footer">
        <div class="pull-right hidden-xs">
            <b>Version</b> 1.0.0
        </div>
        <strong>Copyright &copy; 2020 <a href="https://isosystemss.com" target="_blank">ISOSYSTEMS</a>.</strong> All rights
        reserved.
    </footer>

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-white">

        <!-- Tab panes -->
        <div class="tab-content">
            <!-- Home tab content -->
            <div class="tab-pane" id="control-sidebar-home-tab">

                <!-- /.control-sidebar-menu -->

                <!-- /.control-sidebar-menu -->

            </div>
            <!-- /.tab-pane -->

            <!-- /.tab-pane -->
        </div>
    </aside>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\coopmanager\resources\views/dashboard/application/loanList.blade.php ENDPATH**/ ?>