<?php $__env->startSection('header'); ?>
    <header class="main-header">
        <!-- Logo -->
    <?php echo $__env->make('dashboard.brand', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top">
            <!-- Sidebar toggle button-->
            <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
                <span class="sr-only">Toggle navigation</span>
            </a>
            <!-- Navbar Right Menu -->
            <?php echo $__env->make('dashboard.userProfileLink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </nav>
    </header>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.admin.adminLinks', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('change-password', [])->dom;
} elseif ($_instance->childHasBeenRendered('ao3tBu9')) {
    $componentId = $_instance->getRenderedChildComponentId('ao3tBu9');
    $componentTag = $_instance->getRenderedChildComponentTagName('ao3tBu9');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ao3tBu9');
} else {
    $response = \Livewire\Livewire::mount('change-password', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('ao3tBu9', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>

<?php $__env->startSection('main-content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h3>
                <b><?php echo e(\Illuminate\Support\Facades\Auth::user()->name); ?>, <font style="color: green">You are now logged in as an Admin</font></b>
                
            </h3>
        </section><br />

        <!-- Main content -->
        <section class="content">
            <!-- Info boxes -->
            <div class="row">
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box">
                        <span class="info-box-icon bg-aqua"><font style="font-weight: bold; font-size:90px;"><del style="text-decoration-style: double;">N</del></font></span>
                        <div class="info-box-content">
                            <span class="info-box-text" style="font-size: large;font-weight: bold">Total Loan Value</span>
                            <a href="<?php echo e(url('/dashboard/admin/loanApplicationList')); ?>"><span class="info-box-number" style="font-size: 28px;font-weight: bold"><?php echo e(number_format($dashboard_data['total_loan_value'],2)); ?></span></a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box">
                        <span class="info-box-icon bg-aqua"><font style="font-weight: bold; font-size:90px;"><del style="text-decoration-style: double;">N</del></font></span>
                        <div class="info-box-content">
                            <span class="info-box-text" style="font-size: large;font-weight: bold">Loan Recovered</span>
                            <a href="#"><span class="info-box-number" style="font-size: 28px;font-weight: bold"><?php echo e(number_format(round($dashboard_data['total_loan_recovered']),2)); ?></span></a>
                        </div>
                    </div>
                </div>
                <!-- /.col -->
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box">
                        <span class="info-box-icon bg-aqua"><font style="font-weight: bold; font-size:90px;"><del style="text-decoration-style: double;">N</del></font></span>
                        <div class="info-box-content">
                            <span class="info-box-text" style="font-size: large;font-weight: bold">Total Savings</span>
                            <a href=""><span class="info-box-number" style="font-size: 28px;font-weight: bold"><?php echo e(number_format($dashboard_data['total_saving'],2)); ?></span></a>
                        </div>
                    </div>
                </div>
                <!-- /.col -->
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box">
                        <span class="info-box-icon bg-aqua"><font style="font-weight: bold; font-size:90px;"><del style="text-decoration-style: double;">N</del></font></span>
                        <div class="info-box-content">
                            <span class="info-box-text" style="font-size: large;font-weight: bold">Total Debits</span>
                            <a href=""><span class="info-box-number" style="font-size: 28px;font-weight: bold"><?php echo e(number_format($dashboard_data['total_debits'],2)); ?></span></a>
                        </div>
                    </div>
                </div>
                <!-- fix for small devices only -->
                <div class="clearfix visible-sm-block"></div>

                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box">
                        <span class="info-box-icon bg-aqua"><font style="font-weight: bold; font-size:90px;"><del style="text-decoration-style: double;">N</del></font></span>
                        <div class="info-box-content">
                            <span class="info-box-text" style="font-size: large;font-weight: bold">Dividends Earned</span>
                            <a href=""><span class="info-box-number" style="font-size: 28px;font-weight: bold">00.00</span></a>
                        </div>
                        <!-- /.info-box-content -->
                    </div>
                    <!-- /.info-box -->
                </div>
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box">
                        <span class="info-box-icon bg-aqua"><font style="font-weight: bold; font-size:90px;"><del style="text-decoration-style: double;">N</del></font></span>
                        <div class="info-box-content">
                            <span class="info-box-text" style="font-size: large;font-weight: bold">LPD Earned &#160;<small data-toggle="tooltip" data-placement="top" title="Loan Patronage Dividends">?</small></span>
                            <a href=""><span class="info-box-number" style="font-size: 28px;font-weight: bold">00.00</span></a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box">
                        <span class="info-box-icon bg-aqua"><font style="font-weight: bold; font-size:90px;"><del style="text-decoration-style: double;">N</del></font></span>
                        <div class="info-box-content">
                            <span class="info-box-text" style="font-size: large;font-weight: bold">Total Dividends&#160;<small data-toggle="tooltip" data-placement="top" title="Dividends Earned + LPD Earned">?</small></span>
                            <a href=""><span class="info-box-number" style="font-size: 28px;font-weight: bold">00.00</span></a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box">
                        <span class="info-box-icon bg-aqua"><font style="font-weight: bold; font-size:90px;"><del style="text-decoration-style: double;">N</del></font></span>
                        <div class="info-box-content">
                            <span class="info-box-text" style="font-size: large;font-weight: bold">Total Transactions&#160;<small data-toggle="tooltip" data-placement="top" title="Dividends Earned + LPD Earned">?</small></span>
                            <a href=""><span class="info-box-number" style="font-size: 28px;font-weight: bold"><?php echo e(number_format($dashboard_data['total_transaction'],2)); ?></span></a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box">
                        <span class="info-box-icon bg-aqua"><font style="font-weight: bold; font-size:90px;"><del style="text-decoration-style: double;">N</del></font></span>
                        <div class="info-box-content">
                            <span class="info-box-text" style="font-size: large;font-weight: bold">Total Income&#160;<small data-toggle="tooltip" data-placement="top" title="2021 Earned Income">?</small></span>
                            <a href=""><span class="info-box-number" style="font-size: 28px;font-weight: bold"><?php echo e(number_format(round($dashboard_data['total_income']),2)); ?></span></a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box">
                        <span class="info-box-icon bg-aqua"><font style="font-weight: bold; font-size:90px;"><del style="text-decoration-style: double;">N</del></font></span>
                        <div class="info-box-content">
                            <span class="info-box-text" style="font-size: large;font-weight: bold">Total Membership&#160;<small data-toggle="tooltip" data-placement="top" title="2021 Active Members">?</small></span>
                            <a href=""><span class="info-box-number" style="font-size: 28px;font-weight: bold"><?php echo e(count($dashboard_data['members'])); ?></span></a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-md-12">
                    <div class="box box-danger">
                        <div class="box-header with-border">
                            <h3 class="box-title">Members' Transactions</h3>
                            <div class="box-tools pull-right">
                                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                                </button>

                            </div>
                        </div>
                        <?php
                            $transactions = \App\Transaction::all()->take(5);
                        ?>
                        <div class="box-body">
                            <div class="table-responsive">
                                <table class="table no-margin" id="example1">
                                    <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Transaction Type</th>
                                        <th>Transaction Amount</th>
                                        <th>Channel</th>
                                        <th>Status</th>
                                        <th>Transaction Reference</th>
                                        <th>Merchant</th>
                                        <th>Transaction Date</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($transaction->users->name); ?></td>
                                            <td><?php echo e($transaction->transaction_type); ?></td>
                                            <td><del style="text-decoration-style: double">N</del><?php echo e(number_format($transaction->transaction_amount,2)); ?></td>
                                            <td><?php echo e($transaction->channel); ?></td>
                                            <td><span class="label label-success">Successful</span></td>
                                            <td><?php echo e($transaction->transaction_reference); ?></td>
                                            <td>Paystack</td>
                                            <td><?php echo e($transaction->created_at); ?></td>
                                        </tr>
                                    </tbody>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            </div>
                        </div>
                        <div class="box-footer clearfix pull-left">
                            <a href="javascript:void(0)" class="btn btn-sm btn-info btn-flat pull-right">View All Transaction</a>
                        </div>

                    </div>
                    <!-- /.box -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->

            <!-- Main row -->
            <div class="row">
                <!-- Left col -->
                <div class="col-md-8">
                    <!-- MAP & BOX PANE -->
                    <div class="box box-info">
                        <div class="box-header with-border">
                            <h3 class="box-title">Members' Loans</h3>
                            <div class="box-tools pull-right">
                                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                                </button>
                            </div>
                        </div>
                        <!-- /.box-header -->
                        <?php
                           // $user_id = \Illuminate\Support\Facades\Auth::user()->id;
                            $loans = \App\Loan::all()->take(5);
                        ?>
                        <div class="box-body">
                            <div class="table-responsive">
                                <table class="table no-margin" >
                                    <thead>
                                    <tr>
                                        <th>Applicant</th>
                                        <th>Loan Type</th>
                                        <th>Loan Amount(<del style="text-decoration-style: double">N</del>)</th>
                                        <th>Total Payable(<del style="text-decoration-style: double">N</del>)</th>
                                        <th>Monthly Interest Payable(<del style="text-decoration-style: double">N</del>)</th>
                                        <th>Total Interest Payable(<del style="text-decoration-style: double">N</del>)</th>
                                        <th>Loan Balance</th>
                                        <th>Loan State</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loan->users->name); ?></td>
                                            <td><?php echo e($loan->loan_type); ?></td>
                                            <td><?php echo e(number_format($loan->loan_amount,2)); ?></td>
                                            <td><?php echo e(number_format($loan->total_amount_payable,2)); ?></td>
                                            <td><?php echo e(number_format($loan->monthly_interest_payable,2)); ?></td>
                                            <td><?php echo e(number_format($loan->total_interest_payable,2)); ?></td>
                                            <td><?php echo e($loan->loan_balance); ?></td>
                                            <?php if($loan->status=='Processing'): ?>
                                                <td><span class="label label-warning"><?php echo e($loan->status); ?></span></td>
                                            <?php endif; ?>
                                            <?php if($loan->status=='Approved'): ?>
                                                <td><span class="label label-success"><?php echo e($loan->status); ?></span></td>
                                            <?php endif; ?>
                                            <?php if($loan->status=='Rejected'): ?>
                                                <td><span class="label label-danger"><?php echo e($loan->status); ?></span></td>
                                            <?php endif; ?>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="box-footer clearfix">
                            <a href="/dashboard/admin/loanApplicationList" class="btn btn-sm btn-info btn-flat pull-right">View All Loans</a>
                        </div>
                    </div>

                    <!-- TABLE: LATEST ORDERS -->
                    <div class="box box-info pull-right">
                        <div class="box-header with-border">
                            <h3 class="box-title">Members' Monthly Savings</h3>

                            <div class="box-tools pull-right">
                                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                                </button>
                            </div>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body">
                            <div class="table-responsive">
                                <table class="table no-margin">
                                    <thead>
                                    <tr>
                                        <th>Order ID</th>
                                        <th>Item</th>
                                        <th>Status</th>
                                        <th>Popularity</th>
                                    </tr>
                                    </thead>
                                    <tbody>


                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.box-body -->
                        <div class="box-footer clearfix">
                            <a href="javascript:void(0)" class="btn btn-sm btn-default btn-flat pull-right">View All Orders</a>
                        </div>
                        <!-- /.box-footer -->
                    </div>
                    <!-- /.box -->
                    <!-- /.box -->
                </div>
                <!-- /.col -->

                <div class="col-md-4">
                    <!-- PRODUCT LIST -->
                    <div class="box box-primary">
                        <div class="box-header with-border">
                            <h3 class="box-title">Available Loan Products</h3>

                            <div class="box-tools pull-right">
                                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                                </button>
                            </div>
                        </div>
                        <!-- /.box-header -->

                        <div class="box-body">
                            <?php $__currentLoopData = $dashboard_data['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <ul class="products-list product-list-in-box">
                                    <li class="item">
                                        <div class="product-info">
                                            <a class="product-title"><?php echo e($product['item_name']); ?>

                                                <span class="label label-info pull-right"><del style="text-decoration-style: double">N</del><?php echo e(number_format($product['item_price'],2)); ?></span></a>
                                            <span class="product-description">
                                          <?php echo e($product['item_description']); ?>

                                        </span>
                                        </div>
                                    </li>
                                </ul>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <!-- /.box-body -->
                        <div class="box-footer text-center">
                            <a href="javascript:void(0)" class="uppercase">View All Products</a>
                        </div>
                        <!-- /.box-footer -->
                    </div>
                    <!-- /.box -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

    <footer class="main-footer">
        <div class="pull-right hidden-xs">
            <b>Version</b> 2.4.0
        </div>
        <strong>Copyright &copy; 2021 Nepza Cooperative <a href="https://isosystemss.com" target="_blank">ISOSYSTEMS</a>.</strong> All rights
        reserved.
    </footer>

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
        <!-- Create the tabs -->
        <ul class="nav nav-tabs nav-justified control-sidebar-tabs">
            <li><a href="#control-sidebar-home-tab" data-toggle="tab"><i class="fa fa-home"></i></a></li>
            <li><a href="#control-sidebar-settings-tab" data-toggle="tab"><i class="fa fa-gears"></i></a></li>
        </ul>
        <!-- Tab panes -->
        <div class="tab-content">
            <!-- Home tab content -->
            <div class="tab-pane" id="control-sidebar-home-tab">
                <h3 class="control-sidebar-heading">Recent Activity</h3>
                <ul class="control-sidebar-menu">
                    <li>
                        <a href="javascript:void(0)">
                            <i class="menu-icon fa fa-birthday-cake bg-red"></i>

                            <div class="menu-info">
                                <h4 class="control-sidebar-subheading">Langdon's Birthday</h4>

                                <p>Will be 23 on April 24th</p>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="javascript:void(0)">
                            <i class="menu-icon fa fa-user bg-yellow"></i>

                            <div class="menu-info">
                                <h4 class="control-sidebar-subheading">Frodo Updated His Profile</h4>

                                <p>New phone +1(800)555-1234</p>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="javascript:void(0)">
                            <i class="menu-icon fa fa-envelope-o bg-light-blue"></i>

                            <div class="menu-info">
                                <h4 class="control-sidebar-subheading">Nora Joined Mailing List</h4>

                                <p>nora@example.com</p>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="javascript:void(0)">
                            <i class="menu-icon fa fa-file-code-o bg-green"></i>

                            <div class="menu-info">
                                <h4 class="control-sidebar-subheading">Cron Job 254 Executed</h4>

                                <p>Execution time 5 seconds</p>
                            </div>
                        </a>
                    </li>
                </ul>
                <!-- /.control-sidebar-menu -->

                <h3 class="control-sidebar-heading">Tasks Progress</h3>
                <ul class="control-sidebar-menu">
                    <li>
                        <a href="javascript:void(0)">
                            <h4 class="control-sidebar-subheading">
                                Custom Template Design
                                <span class="label label-danger pull-right">70%</span>
                            </h4>

                            <div class="progress progress-xxs">
                                <div class="progress-bar progress-bar-danger" style="width: 70%"></div>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="javascript:void(0)">
                            <h4 class="control-sidebar-subheading">
                                Update Resume
                                <span class="label label-success pull-right">95%</span>
                            </h4>

                            <div class="progress progress-xxs">
                                <div class="progress-bar progress-bar-success" style="width: 95%"></div>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="javascript:void(0)">
                            <h4 class="control-sidebar-subheading">
                                Laravel Integration
                                <span class="label label-warning pull-right">50%</span>
                            </h4>

                            <div class="progress progress-xxs">
                                <div class="progress-bar progress-bar-warning" style="width: 50%"></div>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="javascript:void(0)">
                            <h4 class="control-sidebar-subheading">
                                Back End Framework
                                <span class="label label-primary pull-right">68%</span>
                            </h4>

                            <div class="progress progress-xxs">
                                <div class="progress-bar progress-bar-primary" style="width: 68%"></div>
                            </div>
                        </a>
                    </li>
                </ul>
                <!-- /.control-sidebar-menu -->

            </div>
            <!-- /.tab-pane -->

            <!-- Settings tab content -->
            <div class="tab-pane" id="control-sidebar-settings-tab">
                <form method="post">
                    <h3 class="control-sidebar-heading">General Settings</h3>

                    <div class="form-group">
                        <label class="control-sidebar-subheading">
                            Report panel usage
                            <input type="checkbox" class="pull-right" checked>
                        </label>

                        <p>
                            Some information about this general settings option
                        </p>
                    </div>
                    <!-- /.form-group -->

                    <div class="form-group">
                        <label class="control-sidebar-subheading">
                            Allow mail redirect
                            <input type="checkbox" class="pull-right" checked>
                        </label>

                        <p>
                            Other sets of options are available
                        </p>
                    </div>
                    <!-- /.form-group -->

                    <div class="form-group">
                        <label class="control-sidebar-subheading">
                            Expose author name in posts
                            <input type="checkbox" class="pull-right" checked>
                        </label>

                        <p>
                            Allow the user to show his name in blog posts
                        </p>
                    </div>
                    <!-- /.form-group -->

                    <h3 class="control-sidebar-heading">Chat Settings</h3>

                    <div class="form-group">
                        <label class="control-sidebar-subheading">
                            Show me as online
                            <input type="checkbox" class="pull-right" checked>
                        </label>
                    </div>
                    <!-- /.form-group -->

                    <div class="form-group">
                        <label class="control-sidebar-subheading">
                            Turn off notifications
                            <input type="checkbox" class="pull-right">
                        </label>
                    </div>
                    <!-- /.form-group -->

                    <div class="form-group">
                        <label class="control-sidebar-subheading">
                            Delete chat history
                            <a href="javascript:void(0)" class="text-red pull-right"><i class="fa fa-trash-o"></i></a>
                        </label>
                    </div>
                    <!-- /.form-group -->
                </form>
            </div>
            <!-- /.tab-pane -->
        </div>
    </aside>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\coopmanager\resources\views/dashboard/admin/adminHome.blade.php ENDPATH**/ ?>