<?php $__env->startSection('header'); ?>
    <header class="main-header">
        <!-- Logo -->
    <?php echo $__env->make('dashboard.brand', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top">
            <!-- Sidebar toggle button-->
            <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
                <span class="sr-only">Toggle navigation</span>
            </a>
            <!-- Navbar Right Menu -->
            <?php echo $__env->make('dashboard.userProfileLink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </nav>
    </header>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.admin.adminLinks', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="content-wrapper">
        <section class="content" xmlns:wire="http://www.w3.org/1999/xhtml" xmlns:nwire="http://www.w3.org/1999/xhtml">
            <div class="row col-md-10 col-lg-10 flex justify-content-center">

                <div class="pull-right" style="width: 100%; display: flex; justify-content: center; align-items: center;">
                    <img src="<?php echo e(asset('custom/img')); ?>/nepza_logo.jpg" width="100" height="90" alt="" />
                    <span style="font-size: 24px; font-weight: bolder; color: #0c5460; line-height: 17px;">
                            NEPZA STAFF MULTIPURPOSE CO-OPERATIVE SOCIETY LIMITED<br />
                            <small style="font-size: 13px; color: #0c5460; align-items: center; ! important;">
                                2, Zambezi Crescent Cadestral Zone A6, Behind Merit House, Off Aguiyi Ironsi Street, Maitama, Abuja<br />
                               &#160;&#160;&#160; &#160; &#160; &#160; &#160; &#160; &#160;&#160; &#160; &#160; &#160; &#160; &#160; Contact GSM: 08054222750; 08086664932; Email: nepzacoop@yahoo.com<br />
                                &#160;&#160;&#160; &#160; &#160; &#160; &#160; &#160; &#160;&#160;&#160;&#160; &#160; &#160; &#160; &#160; &#160; &#160;&#160;&#160;&#160; &#160; &#160; &#160; &#160; &#160; &#160;
                                &#160;&#160;&#160; &#160; &#160; &#160; &#160; &#160; &#160;Motto: Unity & Progress
                            </small>
                        </span>
                </div>
            </div>
            <br />
            <section class="content">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="box box-danger">
                            <div class="box-header">
                                <?php if(Auth::user()->user_role == 'Admin1' && $application->approval_status == 'Processing'): ?>
                                    <button style="font-weight: bold;font-size: 15px;" type="submit" id="sec_approve" value="sec_approved" class="btn btn-primary">Sec Approve Membership</button>
                                    <button style="font-weight: bold;font-size: 15px;" type="submit" id="chair_approve" value="chair_approved" class="btn btn-primary">Pres. Approve Membership</button>
                                    <button style="font-weight: bold;font-size: 15px;" type="submit" id="reject_loan" value="reject_loan" class="btn btn-danger">Reject Membership</button>
                                <?php elseif(Auth::user()->user_role == 'Admin1' && $application->approval_status == 'Approved'): ?>
                                
                                    <button style="font-weight: bold;font-size: 15px;" type="submit" id="reject_loan" value="reject_loan" class="btn btn-danger">Archive Member</button>
                                <?php elseif(Auth::user()->user_role == 'Admin1' && $application->approval_status == 'Rejected'): ?>
                                    <button style="font-weight: bold;font-size: 15px;" type="submit" id="revoke_rejection" value="revoke_rejection" class="btn btn-bitbucket">Set to Draft</button>
                                <?php endif; ?>
                                <?php if(Auth::user()->user_role == 'Admin2' && $application->approval_status == 'Processing'): ?>
                                    <button style="font-weight: bold;font-size: 15px;" type="submit" id="sec_approve" value="sec_approved" class="btn btn-primary">Sec Approve Membership</button>
                                    <button style="font-weight: bold;font-size: 15px;" type="submit" id="reject_loan" value="reject_loan" class="btn btn-danger">Reject Membership</button>
                                <?php elseif(Auth::user()->user_role == 'Admin2' && $application->approval_status == "Rejected"): ?>
                                    <button style="font-weight: bold;font-size: 15px;" type="submit" id="revoke_rejection" value="revoke_rejection" class="btn btn-bitbucket">Set to Draft</button>
                               <?php elseif(Auth::user()->user_role == 'Admin2' && $application->approval_status == "Approved"): ?>
                                        <button style="font-weight: bold;font-size: 15px;" type="submit" id="reject_loan" value="reject_loan" class="btn btn-danger">Archive Member</button>
                                <?php endif; ?>

                                <div class="container-fluid pull-right" style=" display: inline-flex;">
                                    <ol class="breadcrumb breadcrumb-arrow" style="font-weight: bold;font-size: 15px;">
                                        <?php if($application->approval_count == 1): ?>
                                            <li id="sa" style=""><a hreff="#" style="color: green">Secretary Approved</a></li>
                                        <?php endif; ?>
                                        <?php if($application->approval_count == 2): ?>
                                            <li id="sa"><a hreff="#" style="color: green">Secretary Approved</a></li>
                                            <li id="ca" ><a hreff="#" style="color: green">President Approved</a></li>
                                        <?php endif; ?>
                                        <?php if($application->approval_status == 'Processing'): ?>
                                            <li class="sa" ><a hreff="#" style="">Await Sec Approval</a></li>
                                            <li class="ca"><a hreff="#" style="">Await Pres. Approval</a></li>
                                        <?php endif; ?>
                                        <?php if($application->approval_status == "Rejected"): ?>
                                            <li id="sa"><a hreff="#" style="color: darkred">Membership Rejected</a></li>
                                        <?php endif; ?>
                                    </ol>
                                </div>

                                <script>
                                    toastr.options = {
                                        "closeButton": true,
                                        "newestOnTop": true,
                                        "positionClass": "toast-top-right",
                                        "showDuration": "500",
                                    };

                                    $( "#sec_approve" ).on( "click", function(e) {
                                        e.preventDefault();
                                        let sec_approve = $("#sec_approve").val();
                                        let application_id = $("#application_id").val();
                                        let staff_email = $('#staff_email').val();
                                        let staff_name = $('#staff_name').val();
                                        $('.preloader').show();

                                        data = {
                                            _token: "<?php echo e(csrf_token()); ?>",
                                            sec_approve: sec_approve,
                                            application_id: application_id,
                                            staff_email: staff_email,
                                            staff_name: staff_name,
                                        };

                                        $.ajax({
                                            url: '<?php echo e(URL::to('/handleAdminMembershipApproval')); ?>',
                                            type: 'POST',
                                            dataType: 'json',
                                            data: data,
                                            success: function (response) {
                                                if(response.success === true) {
                                                    $('.preloader').hide();
                                                    setTimeout(function () {// wait for 5 secs(2)
                                                        location.reload(); // then reload the page.(3)
                                                    }, 2000);
                                                    toastr.success(response.message);
                                                }else if(response.warning === true){
                                                    $('.preloader').hide();
                                                    setTimeout(function(){// wait for 5 secs(2)
                                                        //location.reload(); // then reload the page.(3)
                                                    }, 2000);
                                                    toastr.warning(response.message);

                                                }else{
                                                    $('.preloader').hide();
                                                    //window.location=response.url;
                                                }
                                            },
                                        });
                                    });
                                    $( "#chair_approve" ).on( "click", function(e) {
                                        e.preventDefault();
                                        let chair_approve = $("#chair_approve").val();
                                        let application_id = $("#application_id").val();
                                        let staff_email = $('#staff_email').val();
                                        let staff_name = $('#staff_name').val();
                                        $('.preloader').show();

                                        data = {
                                            _token: "<?php echo e(csrf_token()); ?>",
                                            chair_approve: chair_approve,
                                            application_id: application_id,
                                            staff_email: staff_email,
                                            staff_name: staff_name,
                                        };

                                        $.ajax({
                                            url: '<?php echo e(URL::to('/handleAdminMembershipApproval')); ?>',
                                            type: 'POST',
                                            dataType: 'json',
                                            data: data,
                                            success: function (response) {
                                                if(response.success === true) {
                                                    $('.preloader').hide();
                                                    setTimeout(function () {// wait for 5 secs(2)
                                                        location.reload(); // then reload the page.(3)
                                                    }, 2000);
                                                    toastr.success(response.message);
                                                }else if(response.warning === true){
                                                    $('.preloader').hide();
                                                    setTimeout(function(){// wait for 5 secs(2)
                                                        //location.reload(); // then reload the page.(3)
                                                    }, 2000);
                                                    toastr.warning(response.message);

                                                }else{
                                                    $('.preloader').hide();
                                                    //window.location=response.url;
                                                }
                                            },
                                        });
                                    });
                                    $( "#reject_loan" ).on( "click", function(e) {
                                        e.preventDefault();
                                        let reject_loan = $("#reject_loan").val();
                                        let application_id = $("#application_id").val();
                                        let reason_for_rejection = $("#reason_for_rejection").val();
                                        let staff_email = $('#staff_email').val();
                                        let staff_name = $('#staff_name').val();

                                        if(reason_for_rejection == ''){
                                            $("#show_reason").show();
                                            return false;
                                        }
                                        $('.preloader').show();

                                        data = {
                                            _token: "<?php echo e(csrf_token()); ?>",
                                            reject_loan: reject_loan,
                                            application_id: application_id,
                                            reason_for_rejection: reason_for_rejection,
                                            staff_email: staff_email,
                                            staff_name: staff_name,

                                        };

                                        $.ajax({
                                            url: '<?php echo e(URL::to('/handleAdminMembershipApproval')); ?>',
                                            type: 'POST',
                                            dataType: 'json',
                                            data: data,
                                            success: function (response) {
                                                if(response.success === true) {
                                                    $('.preloader').hide();
                                                    setTimeout(function () {// wait for 5 secs(2)
                                                        location.reload(); // then reload the page.(3)
                                                    }, 2000);
                                                    toastr.success(response.message);
                                                }else if(response.warning === true){
                                                    $('.preloader').hide();
                                                    setTimeout(function(){// wait for 5 secs(2)
                                                        location.reload(); // then reload the page.(3)
                                                    }, 2000);
                                                    toastr.warning(response.message);

                                                }else{
                                                    $('.preloader').hide();
                                                    //window.location=response.url;
                                                }
                                            },
                                        });
                                    });
                                    $( "#revoke_rejection" ).on( "click", function(e) {
                                        e.preventDefault();
                                        let revoke_rejection = $("#revoke_rejection").val();
                                        let application_id = $("#application_id").val();
                                        let staff_email = $('#staff_email').val();
                                        let staff_name = $('#staff_name').val();
                                        $('.preloader').show();

                                        data = {
                                            _token: "<?php echo e(csrf_token()); ?>",
                                            revoke_rejection: revoke_rejection,
                                            application_id: application_id,
                                            staff_email: staff_email,
                                            staff_name: staff_name,
                                        };

                                        $.ajax({
                                            url: '<?php echo e(URL::to('/handleAdminMembershipApproval')); ?>',
                                            type: 'POST',
                                            dataType: 'json',
                                            data: data,
                                            success: function (response) {
                                                if(response.success === true){
                                                    $('.preloader').hide();
                                                    setTimeout(function(){// wait for 5 secs(2)
                                                        location.reload(); // then reload the page.(3)
                                                    }, 2000);
                                                    toastr.warning(response.message);
                                                }else{
                                                    $('.preloader').hide();
                                                    //window.location=response.url;
                                                }

                                            },
                                        });
                                    });
                                </script>

                            </div>

                            <!-- /.box-header -->
                            <div class="box-body">
                                <!-- /.row -->
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="box"  style="margin-top: -13px;">
                                            <div class="box-header with-borderr">
                                                <div class="box-tools pull-right">
                                                    <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                                                    </button>
                                                </div>
                                            </div>
                                            <div class="box-body" style="padding-bottom: 400px">
                                                <style>
                                                    .loader{
                                                        position: absolute;
                                                        left: 70%;
                                                        top: 20%;
                                                        -webkit-transform: translate(-50%, -50%);
                                                        transform: translate(-50%, -50%);
                                                    }
                                                </style>
                                                <script>
                                                    $(document).ready(function(){
                                                        if($('#approval_count').val() == 1){
                                                            $('#sec_approve').prop("disabled",true);
                                                            $('.sa').hide();
                                                        }else{
                                                            $('#chair_approve').prop("disabled",true);
                                                        }
                                                        if($('#approval_count').val() == 2){
                                                            $('.ca').hide();
                                                        }
                                                    })(jQuery);
                                                </script>
                                                <div class="row">
                                                    <!-- textarea -->
                                                    <div class="form-group" id="show_reason" style="width: 70%; margin: auto; display: none">
                                                        <textarea class="form-control" rows="3" id="reason_for_rejection" value="" placeholder="Kindly provide the reason(s) membership is being rejected"></textarea>
                                                    </div>
                                                    <div class="preloader">
                                                        <img src="<?php echo e(asset('custom/img')); ?>/loader.gif" alt="" />
                                                    </div>
                                                    <style>
                                                        .preloader{
                                                            display: none;
                                                            position: absolute;
                                                            left: 50%;
                                                            top: 20%;
                                                            -webkit-transform: translate(-50%, -50%);
                                                            transform: translate(-50%, -50%);
                                                        }
                                                    </style>

                                                    <div class="box-body table-responsive">
                                                        <table class="table table-bordered table-striped"  style="border: 2px;font-size: medium">
                                                        <input type="hidden" value="<?php echo e($application->id); ?>" id="application_id" />
                                                        <input type="hidden" value="<?php echo e($application->users->email); ?>" id="staff_email" />
                                                        <input type="hidden" value="<?php echo e($application->users->name); ?>" id="staff_name" />
                                                        <input type="hidden" value="<?php echo e($application->approval_count); ?>" id="approval_count" />
                                                        <thead>
                                                            <tr style="font-size: 18px;">
                                                                <th>Photograph</th>
                                                                <th>Personal Information</th>
                                                                <th>Official Information</th>
                                                                <th>NoK Information</th>
                                                                <th>Referees' Information</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                        <tr>
                                                            <td style="border: 1px solid black; width: 150px">
                                                               <img src="<?php echo e(asset('/storage/'. $application->users->passport_url)); ?>" class="user-image" height="150" width="150">
                                                            </td>
                                                            <td>
                                                                <strong>First Name:</strong>&#160;&#160;&#160;<?php echo e($application->first_name); ?><br/>
                                                                <?php if($application->middle_name != ''): ?><strong>Middle Name:</strong>&#160;&#160;&#160;<?php echo e($application->middle_name); ?><br/><?php endif; ?>
                                                                <strong>Last Name:</strong>&#160;&#160;&#160;<?php echo e($application->last_name); ?><br/>
                                                                <strong>Gender:</strong>&#160;&#160;&#160;<?php echo e($application->gender); ?><br/>
                                                                <strong>Email:</strong>&#160;&#160;&#160;<?php echo e($application->users->email); ?><br/>
                                                                <strong>Telephone:</strong>&#160;&#160;&#160;<?php echo e($application->users->phone_no); ?><br/>
                                                                <strong>Contact Address:</strong>&#160;&#160;&#160;<?php echo e($application->residential_address); ?><br/>
                                                            </td>
                                                            <td>
                                                                <strong>Membership No:</strong>&#160;&#160;&#160;<?php echo e($application->users->member_id); ?><br/>
                                                                <strong>Account No:</strong>&#160;&#160;&#160;<?php echo e($application->users->ippis_no); ?><br/>
                                                                <strong>Designation:</strong>&#160;&#160;&#160;<?php echo e($application->designation); ?><br/>
                                                                <strong>Department:</strong>&#160;&#160;&#160;<?php echo e($application->department); ?><br/>
                                                                <strong>Office Location:</strong>&#160;&#160;&#160;<?php echo e($application->office_location); ?><br/>
                                                            </td>
                                                            <td>
                                                                <strong>First Name:</strong>&#160;&#160;&#160;<?php echo e($application->nok_fname); ?><br/>
                                                                <?php if($application->nok_mname != ''): ?><strong>Middle Name:</strong>&#160;&#160;&#160;<?php echo e($application->nok_mname); ?><br/><?php endif; ?>
                                                                <strong>Last Name:</strong>&#160;&#160;&#160;<?php echo e($application->nok_lname); ?><br/>
                                                                <strong>Relationship:</strong>&#160;&#160;&#160;<?php echo e($application->nok_relationship); ?><br/>
                                                                <strong>Telephone:</strong>&#160;&#160;&#160;<?php echo e($application->nok_phone_number); ?><br/>
                                                                <?php if($application->nok_email != ''): ?><strong>Email:</strong>&#160;&#160;&#160;<?php echo e($application->nok_email); ?><br/><?php endif; ?>
                                                                <strong>Contact Address:</strong>&#160;&#160;&#160;<?php echo e($application->nok_address); ?><br/>
                                                            </td>
                                                            <td>
                                                                <strong>1st Referee's Name:</strong>&#160;&#160;&#160;<?php echo e($application->referee_one); ?><br/>
                                                                <strong>Telephone:</strong>&#160;&#160;&#160;<br/>
                                                                <strong>2nd Referee's Name:</strong>&#160;&#160;&#160;<?php echo e($application->referee_two); ?><br/>
                                                                <strong>Telephone:</strong>&#160;&#160;&#160;<br/>
                                                            </td>












                                                        </tr>
                                                        </tbody>
                                                    </table>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <!-- /.box -->
                                    </div>
                                    <!-- /.col -->
                                </div>
                                <!-- /.row -->
                            </div>
                            <!-- /.box-body -->
                        </div>
                        <!-- /.box -->
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </section>
            <!-- /.content -->
            <!-- /.content-wrapper -->
        </section>
        <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('change-password', [])->dom;
} elseif ($_instance->childHasBeenRendered('DSdjivs')) {
    $componentId = $_instance->getRenderedChildComponentId('DSdjivs');
    $componentTag = $_instance->getRenderedChildComponentTagName('DSdjivs');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('DSdjivs');
} else {
    $response = \Livewire\Livewire::mount('change-password', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('DSdjivs', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
    </div>
    <footer class="main-footer">
        <div class="pull-right hidden-xs">
            <b>Version</b> 1.0.0
        </div>
        <strong>Copyright &copy; 2021 <a href="https://isosystemss.com" target="_blank">ISOSYSTEMS</a>.</strong> All rights
        reserved.
    </footer>

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-white">

        <!-- Tab panes -->
        <div class="tab-content">
            <!-- Home tab content -->
            <div class="tab-pane" id="control-sidebar-home-tab">

                <!-- /.control-sidebar-menu -->

                <!-- /.control-sidebar-menu -->

            </div>
            <!-- /.tab-pane -->

            <!-- /.tab-pane -->
        </div>
    </aside>
    <style>
        .breadcrumb-arrow {
            min-height: 36px;
            line-height: 36px;
            list-style: none;
            overflow: auto;
            background-color: #ffffff ! important;
            margin-bottom: -20px;
            margin-top: -10px;
        }

        .breadcrumb-arrow li:first-child a {
            border-radius: 4px 0 0 4px;
            -webkit-border-radius: 4px 0 0 4px;
            -moz-border-radius: 4px 0 0 4px;
        }

        .breadcrumb-arrow li,
        .breadcrumb-arrow li a,
        .breadcrumb-arrow li span {
            display: inline-block;
        }

        .breadcrumb-arrow li:not(:first-child) {
            margin-left: -5px;
        }

        .breadcrumb-arrow li+li:before {
            padding: 0;
            content: "";
        }

        .breadcrumb-arrow li span {
            padding: 0 10px;
        }

        .breadcrumb-arrow li a,
        .breadcrumb-arrow li:not(:first-child) span {
            height: 36px;
            padding: 0 10px 0 25px;

        }

        .breadcrumb-arrow li:first-child a {
            padding: 0 10px;
        }

        .breadcrumb-arrow li a {
            position: relative;
            color: #fff;
            text-decoration: none;
            background-color:#3C8DBC;
            border: 1px solid #3C8DBC;
        }

        .breadcrumb-arrow li:first-child a {
            padding-left: 10px;
        }

        .breadcrumb-arrow li a:after,
        .breadcrumb-arrow li a:before {
            position: absolute;
            top: -1px;
            width: 0;
            height: 0;
            content: '';
            border-top: 18px solid transparent;
            border-bottom: 18px solid transparent;
        }

        .breadcrumb-arrow li a:before {
            right: -10px;
            z-index: 3;
            border-left-color: #3C8DBC;
            border-left-style: solid;
            border-left-width: 10px;
        }

        .breadcrumb-arrow li a:after {
            right: -11px;
            z-index: 2;
            border-left: 11px solid #fff;
        }

        .breadcrumb-arrow li a:focus:before,
        .breadcrumb-arrow li a:hover:before {
            border-left-color: #3C8DBC;
        }

        .breadcrumb-arrow li a:active {
            background-color: #3C8DBC;
            border: 1px solid #3C8DBC;
        }

        .breadcrumb-arrow li a:active:after,
        .breadcrumb-arrow li a:active:before {
            border-left-color: #3C8DBC;
        }

        .breadcrumb-arrow li.active:first-child span {
            padding-left: 10px;
        }

        .breadcrumb-arrow li.active span:after,
        .breadcrumb-arrow li.active span:before {
            position: absolute;
            top: -1px;
            width: 0;
            height: 0;
            content: '';
            border-top: 18px solid transparent;
            border-bottom: 18px solid transparent;
        }

        .breadcrumb-arrow li.active span:before {
            right: -10px;
            z-index: 3;
            border-left-color: #007bff;
            border-left-style: solid;
            border-left-width: 11px;
        }

        .breadcrumb-arrow li.active span:after {
            right: -11px;
            z-index: 2;
            border-left: 10px solid #007bff;
        }
    </style>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\coopmanager\resources\views/dashboard/admin/membershipApproval.blade.php ENDPATH**/ ?>