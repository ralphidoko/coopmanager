<?php $__env->startSection('sidebar'); ?>
    <aside class="main-sidebar" style="font-size: large ! important; background-color: #fff; color: #0b2e13;">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
                <?php
                    $name = Route::currentRouteName(); //echo $name;
                ?>
            <ul class="sidebar-menu" data-widget="tree" >
                <li class="active treeview menu-open">
                    <a href="#">
                        <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                        <span class="pull-right-container">
                                    <i class="fa fa-angle-left pull-right"></i>
                                    </span>
                        <?php if($name !=='home'): ?>
                            <ul class="treeview-menu">
                                <li><a href="<?php echo e(url('/dashboard/admin/adminHome')); ?>"><i class="fa fa-home"></i>Admin Dashboard</a></li>
                            </ul>
                        <?php endif; ?>
                    </a>
                </li>
                <li class="treeview">
                    <a href="#">
                        <i class="fa fa-money"></i>
                        <span>Loan Management</span>
                        <span class="pull-right-container"></span>
                    </a>
                    <ul class="treeview-menu">
                        <li><a href="<?php echo e(url('/dashboard/admin/loanApplicationList/')); ?>"><i class="fa fa-eye"></i>View all Loans</a></li>
                        <li><a href="<?php echo e(url('/dashboard/admin/loanInstallmentsPayment/')); ?>"><i class="fa fa-circle-o"></i> Loan Repayments</a></li>
                    </ul>
                </li>
                <li class="treeview">
                    <a href="#">
                        <i class="fa fa-bank"></i>
                        <span>Savings/Withdrawals</span>
                        <span class="pull-right-container">
                          <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu">
                        <li><a href="<?php echo e(url('/dashboard/admin/savingsAuthorizations')); ?>"><i class="fa fa-check"></i>Savings Authorization</a></li>
                        <li><a href="<?php echo e(url('/dashboard/admin/savingsWithdrawals')); ?>"><i class="fa fa-check"></i>Withdrawals Approval</a></li>
                        <li><a href="<?php echo e(url('/dashboard/admin/savingsWithdrawalsTransactions')); ?>"><i class="fa fa-exchange"></i>Members' Account Transactions</a></li>
                    </ul>
                </li>
                <li class="treeview">
                    <a href="#">
                        <i class="fa fa-upload"></i> <span>File Management</span>
                        <span class="pull-right-container">
                                    <i class="fa fa-angle-left pull-right"></i>
                                    </span>
                    </a>
                    <ul class="treeview-menu">
                        <li><a href="<?php echo e(url('dashboard/admin/adminFile/monthlyDepositUpload')); ?>"><i class="fa fa-upload"></i> Upload Monthly Savings</a></li>
                        <li><a href="<?php echo e(url('dashboard/admin/adminFile/downloadTemplate')); ?>"><i class="fa fa-download"></i> Download Savings Template</a></li>


                    </ul>
                </li>
                <li class="treeview">
                    <a href="#">
                        <i class="fa fa-user"></i> <span>Member Management</span>
                        <span class="pull-right-container">
                                    <i class="fa fa-angle-left pull-right"></i>
                                    </span>
                    </a>
                    <ul class="treeview-menu">
                        <li><a href="<?php echo e(url('/dashboard/admin/membershipApplication')); ?>"><i class="fa fa-eye"></i>Membership Applications</a></li>

                        <li><a href=""><i class="fa fa-eye"></i>View all Members</a></li>
                    </ul>
                </li>
                <li class="treeview">
                    <a href="#">
                        <i class="fa fa-user"></i> <span>User Management</span>
                        <span class="pull-right-container">
                                    <i class="fa fa-angle-left pull-right"></i>
                                    </span>
                    </a>
                    <ul class="treeview-menu">
                        <li><a href=""><i class="fa fa-eye"></i>Manage Admin Users</a></li>
                        <li><a href=""><i class="fa fa-eye"></i>View Admin Users</a></li>
                    </ul>
                </li>
                <li class="treeview">
                    <a href="#">
                        <i class="fa fa-money"></i> <span>Accounting</span>
                        <span class="pull-right-container">
                                    <i class="fa fa-angle-left pull-right"></i>
                                    </span>
                    </a>
                    <ul class="treeview-menu">
                        <li><a href="<?php echo e(url('dashboard/admin/accounting/createAccountChart')); ?>"><i class="fa fa-plus"></i>Chart of Accounts</a></li>
                        <li><a href=""><i class="fa fa-plus"></i>Asset Management</a></li>
                        <li><a href=""><i class="fa fa-plus"></i>Expense Management</a></li>
                    </ul>
                </li>
                <li class="treeview">
                    <a href="#">
                        <i class="fa fa-shopping-cart"></i> <span>Products Management</span>
                        <span class="pull-right-container">
                           <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu">
                        <li><a href=""><i class="fa fa-plus"></i>Add Product</a></li>
                        <li><a href=""><i class="fa fa-eye"></i>Update Product Details</a></li>
                    </ul>
                </li>
                <li class="treeview">
                    <a href="#">
                        <i class="fa fa-user-circle"></i> <span>Elections Management</span>
                        <span class="pull-right-container">
                           <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu">
                        <li><a href=""><i class="fa fa-plus"></i>Setup Categories</a></li>
                        <li><a href=""><i class="fa fa-eye"></i>Setup Contestants</a></li>
                    </ul>
                </li>
                <li class="treeview">
                    <a href="#">
                        <i class="fa fa-pencil"></i> <span>Analysis/Reporting</span>
                        <span class="pull-right-container">
                           <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu">
                        <li><a href="<?php echo e(url('dashboard/admin/accounting/reportTemplate')); ?>"><i class="fa fa-eye"></i>View All Reports</a></li>
                        <li><a href="<?php echo e(url('dashboard/admin/reports/adminReportFilter')); ?>"><i class="fa fa-print"></i>Print Reports With Filter</a></li>






                    </ul>
                </li>
            </ul>
        </section>
    </aside>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\xampp\htdocs\coopmanager\resources\views/dashboard/admin/adminLinks.blade.php ENDPATH**/ ?>