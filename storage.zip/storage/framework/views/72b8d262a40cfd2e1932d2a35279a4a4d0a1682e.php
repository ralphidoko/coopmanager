<?php $__env->startSection('header'); ?>
    <header class="main-header">
        <!-- Logo -->
    <?php echo $__env->make('dashboard.brand', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top">
            <!-- Sidebar toggle button-->
            <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
                <span class="sr-only">Toggle navigation</span>
            </a>
            <!-- Navbar Right Menu -->
            <?php echo $__env->make('dashboard.userProfileLink', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </nav>
    </header>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.admin.adminLinks', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="content-wrapper">
        <section class="content" xmlns:wire="http://www.w3.org/1999/xhtml" xmlns:nwire="http://www.w3.org/1999/xhtml">
            <div class="row col-md-10 col-lg-10 flex justify-content-center">

                <div class="pull-right" style="width: 100%; display: flex; justify-content: center; align-items: center;">
                    <img src="<?php echo e(asset('custom/img')); ?>/nepza_logo.jpg" width="100" height="90" alt="" />
                    <span style="font-size: 24px; font-weight: bolder; color: #0c5460; line-height: 17px;">
                            NEPZA STAFF MULTIPURPOSE CO-OPERATIVE SOCIETY LIMITED<br />
                            <small style="font-size: 13px; color: #0c5460; align-items: center; ! important;">
                                2, Zambezi Crescent Cadestral Zone A6, Behind Merit House, Off Aguiyi Ironsi Street, Maitama, Abuja<br />
                               &#160;&#160;&#160; &#160; &#160; &#160; &#160; &#160; &#160;&#160; &#160; &#160; &#160; &#160; &#160; Contact GSM: 08054222750; 08086664932; Email: nepzacoop@yahoo.com<br />
                                &#160;&#160;&#160; &#160; &#160; &#160; &#160; &#160; &#160;&#160;&#160;&#160; &#160; &#160; &#160; &#160; &#160; &#160;&#160;&#160;&#160; &#160; &#160; &#160; &#160; &#160; &#160;
                                &#160;&#160;&#160; &#160; &#160; &#160; &#160; &#160; &#160;Motto: Unity & Progress
                            </small>
                        </span>
                </div>
            </div>
            <!-- Main content -->
            <section class="content">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="box box-danger" style="padding: 10px ! important;">
                            <div class="box-header">
                                <div class="box-tools pull-right">
                                    <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                                    </button>
                                </div>
                                <h3 class="box-title">List View of Savings Withdrawal Requests</h3>
                            </div>
                            <!-- /.box-header -->
                            <div class="table-responsive">
                                <table id="example1" class="table table-bordered table-striped">
                                    <thead>
                                    <tr>
                                        <th>Account Name</th>
                                        <th>Account Number</th>
                                        <th>Description</th>
                                        <th>Withdrawal Amount(<del style="text-decoration-style: double">N</del>)</th>
                                        <th>Date Submitted</th>
                                        <th>Withdrawal Status</th>
                                    </tr>
                                    </thead>
                                        <?php $__currentLoopData = $savings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $saving): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($saving->users->name != 'Administrator'): ?>
                                            <tr onclick="window.location='/dashboard/admin/savingsWithdrawalApproval/<?php echo e($saving->id); ?>/'" style="cursor: pointer">
                                                <td><?php echo e($saving->users->name); ?></td>
                                                <td><?php echo e($saving->users->ippis_no); ?></td>
                                                <td><?php echo e($saving->description); ?></td>
                                                <td><?php echo e(number_format($saving->amount_withdrawn,2)); ?></td>
                                                <td><?php echo e(date('d-M-Y h:m:s',strtotime($saving->created_at))); ?></td>
                                                <td>
                                                    <?php if($saving->status== 'Processing'): ?>
                                                    <span class="label label-warning"><?php echo e($saving->status); ?></span>
                                                    <?php elseif($saving->status === 'Rejected'): ?>
                                                    <span class="label label-danger"><?php echo e($saving->status); ?>

                                                    <?php elseif($saving->status === 'Approved'): ?>
                                                    <span class="label label-success"><?php echo e($saving->status); ?>

                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            </div>
                            <!-- /.box-body -->
                        </div>
                        <!-- /.box -->
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </section>
            <!-- /.content -->

            <!-- /.content-wrapper -->
            <script>
                $(function () {
                    // $('#example2').DataTable()
                    $('#example1').DataTable({
                        'paging'      : true,
                        'lengthChange': false,
                        'searching'   : true,
                        'ordering'    : true,
                        'info'        : true,
                        'autoWidth'   : false
                    })
                })
            </script>

        </section>

        <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('change-password', [])->dom;
} elseif ($_instance->childHasBeenRendered('pli8cdk')) {
    $componentId = $_instance->getRenderedChildComponentId('pli8cdk');
    $componentTag = $_instance->getRenderedChildComponentTagName('pli8cdk');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('pli8cdk');
} else {
    $response = \Livewire\Livewire::mount('change-password', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('pli8cdk', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
    </div>
    <footer class="main-footer">
        <div class="pull-right hidden-xs">
            <b>Version</b> 1.0.0
        </div>
        <strong>Copyright &copy; 2021 <a href="https://isosystemss.com" target="_blank">ISOSYSTEMS</a>.</strong> All rights
        reserved.
    </footer>

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-white">

        <!-- Tab panes -->
        <div class="tab-content">
            <!-- Home tab content -->
            <div class="tab-pane" id="control-sidebar-home-tab">

                <!-- /.control-sidebar-menu -->

                <!-- /.control-sidebar-menu -->

            </div>
            <!-- /.tab-pane -->

            <!-- /.tab-pane -->
        </div>
    </aside>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\coopmanager\resources\views/dashboard/admin/savingsWithdrawals.blade.php ENDPATH**/ ?>